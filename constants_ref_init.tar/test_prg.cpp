#include "Date.h"
#include "Report.h"
void func(const Report &t) //copy ctor
{
  t.display();
}


int main()
{
  // Create Report r;
  Report r(7, 4, 2014, 10, 15, "Happy 4th!");
  func(r);
}
